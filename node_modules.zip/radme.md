postman collection link => 
https://lively-star-569487.postman.co/workspace/New-Team-Workspace~e0956810-65c7-4330-bfad-ff64a8bec431/collection/25295776-c61eb362-8452-4407-910a-c960cedfe93b?action=share&creator=25295776 

github link => https://github.com/amanmohadikar/machine_task.git

http://localhost:4000/getDataFromApis <= This is the link to get all data from both api's using promise.all
http://localhost:4000/getDataFrom1 <= This is the link to get data from first api
http://localhost:4000/getDataFrom2 <= This is the link to get data from second api
http://localhost:4000/monthlyRevenue <= This is the link to get the total monthly revenue
